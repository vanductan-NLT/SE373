"""Cấu hình project: hằng số hiển thị, giới hạn thực thi và settings đọc từ .env."""

import os
from dataclasses import dataclass

from dotenv import load_dotenv

import paths

PROJECT_NAME = "stage-01-files"
APP_TITLE = "Stage 01: File tools"
CAPABILITY_TEXT = "Tools: read_file (đọc file trong workspace), write_file (ghi vào workspace/output/). Không có skill, không chạy lệnh."

# Giới hạn số lần gọi model trong một lượt chat (ModelCallLimitMiddleware).
MODEL_CALL_LIMIT = 8
# Giới hạn số tool calls trong một lượt chat (ToolCallLimitMiddleware).
TOOL_CALL_LIMIT = 20
# Giới hạn số bước của LangGraph (recursion limit), không phải số tool calls.
RECURSION_LIMIT = 50


@dataclass(frozen=True)
class Settings:
    api_key: str
    model_name: str
    base_url: str | None


def load_settings() -> tuple[Settings | None, list[str]]:
    """Đọc .env của project này. Trả (settings, []) hoặc (None, danh sách biến còn thiếu)."""
    load_dotenv(paths.ENV_PATH, override=False)
    api_key = (os.getenv("OPENAI_API_KEY") or os.getenv("DEEPSEEK_API_KEY") or "").strip()
    model_name = (os.getenv("MODEL_NAME") or os.getenv("DEEPSEEK_MODEL") or "").strip()
    base_url = (os.getenv("OPENAI_BASE_URL") or os.getenv("DEEPSEEK_BASE_URL") or "").strip() or None
    if not base_url and os.getenv("DEEPSEEK_API_KEY"):
        base_url = "https://api.deepseek.com"
    if not model_name and os.getenv("DEEPSEEK_API_KEY"):
        model_name = "deepseek-chat"
    missing = [name for name, value in (("OPENAI_API_KEY hoặc DEEPSEEK_API_KEY", api_key), ("MODEL_NAME hoặc DEEPSEEK_MODEL", model_name)) if not value]
    if missing:
        return None, missing
    return Settings(api_key=api_key, model_name=model_name, base_url=base_url), []

